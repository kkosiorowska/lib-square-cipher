# lib-square-cipher

## Create a file

* python setup.py sdist

## Install package

* pip install git+git@github.com:kkosiorowska/lib-square-cipher.git#egg=lib-square-cipher

## Updating the package

* pip install git+git@github.com:kkosiorowska/lib-square-cipher.git#egg=lib-square-cipher


