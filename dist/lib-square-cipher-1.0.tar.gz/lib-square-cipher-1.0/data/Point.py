class Point:
    def __init__(self, i, j):
        self.i = i
        self.j = j