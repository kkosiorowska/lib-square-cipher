from . import Point
from . import Square